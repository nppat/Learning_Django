Struggled with the assignment for some reason.  I think I'm tired and need a break haha.
I had to reference Tommy and Marynn github, becuase the messaging system, the Django messaging that
is similar to Flash, did not work at all.  I also found a build-in email validator in the Django Docs,
but I think the course wants to use user-built methods first, and then move on to the built-in methods.