I had to watch the lecutre walkthrough to find my errors.  While they were small errors, they certainly were annoying and frustrating.
Django isn't all that hard, just different from the start to finish.
I also forgot to start the clock on how long this took to finish, so I would estimate 4 hoursish.